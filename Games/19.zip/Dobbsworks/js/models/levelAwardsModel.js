"use strict";
var LevelAwardsModel = /** @class */ (function () {
    function LevelAwardsModel(isWR, isFC, isPB) {
        this.isWR = isWR;
        this.isFC = isFC;
        this.isPB = isPB;
    }
    return LevelAwardsModel;
}());
