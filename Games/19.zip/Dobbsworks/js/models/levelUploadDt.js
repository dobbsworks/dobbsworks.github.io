"use strict";
var LevelUploadDT = /** @class */ (function () {
    function LevelUploadDT(Name, LevelData, Thumbnail) {
        this.Name = Name;
        this.LevelData = LevelData;
        this.Thumbnail = Thumbnail;
    }
    return LevelUploadDT;
}());
