class UserDT
{
    constructor(
    public id: number,
    public username: string
    ){}
}