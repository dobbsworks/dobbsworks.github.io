"use strict";
var UserDT = /** @class */ (function () {
    function UserDT(id, username) {
        this.id = id;
        this.username = username;
    }
    return UserDT;
}());
