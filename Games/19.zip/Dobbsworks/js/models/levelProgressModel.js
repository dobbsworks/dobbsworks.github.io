"use strict";
var LevelProgressModel = /** @class */ (function () {
    function LevelProgressModel(LevelId, FrameCount, AttemptCount) {
        this.LevelId = LevelId;
        this.FrameCount = FrameCount;
        this.AttemptCount = AttemptCount;
    }
    return LevelProgressModel;
}());
