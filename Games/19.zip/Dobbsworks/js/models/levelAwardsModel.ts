class LevelAwardsModel
{
    constructor(
    public isWR: boolean,
    public isFC: boolean,
    public isPB: boolean,
    ){}
}