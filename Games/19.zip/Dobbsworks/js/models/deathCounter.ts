interface DeathCounter {
    deathCount: number,
    levelId: number
}