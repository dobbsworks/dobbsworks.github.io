class LevelUploadDT
{
    constructor(
    public Name: string,
    public LevelData: string,
    public Thumbnail: string,
    ){}
}