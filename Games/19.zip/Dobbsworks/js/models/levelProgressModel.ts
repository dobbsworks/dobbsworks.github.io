class LevelProgressModel
{
    constructor(
    public LevelId: number,
    public FrameCount: number,
    public AttemptCount: number,
    ){}
}