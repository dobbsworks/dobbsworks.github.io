class MyLevelsMenu extends Menu {
    stopsMapUpdate = true;
    static selectedLocalSlot: number = -1;
    static selectedCloudId: number = -1;

    cloudSavesTitlePanel: Panel | null = null;
    localSavesTitlePanel: Panel | null = null;
    cloudSavesPanel: Panel | null = null;
    localSavesPanel: Panel | null = null;

    cloudSavesOptionsPanel: Panel | null = null;
    localSavesOptionsPanel: Panel | null = null;

    buttonLocalEdit: Button | null = null;
    buttonLocalUpload: Button | null = null;
    buttonLocalDelete: Button | null = null;

    baseLeftX = 30;
    basePanelWidth = 432;
    baseRightX = 960 - this.basePanelWidth - 30;
    baseY = 70;
    basePanelHeight = 400;

    backgroundColor = "#022";

    ResetLocalSavesPanel(): void {
        MyLevelsMenu.selectedLocalSlot = -1;
        uiHandler.elements = uiHandler.elements.filter(a => a != this.localSavesPanel);
        this.elements = this.elements.filter(a => a != this.localSavesPanel);
        this.localSavesPanel = this.CreateLocalSavesPanel();
        this.elements.push(this.localSavesPanel);
        uiHandler.elements.push(this.localSavesPanel);
    }


    ResetCloudSavesPanel(): void {
        MyLevelsMenu.selectedCloudId = -1;
        uiHandler.elements = uiHandler.elements.filter(a => a != this.cloudSavesPanel);
        this.elements = this.elements.filter(a => a != this.cloudSavesPanel);

        let cloudLevelsPromise = DataService.GetMyLevels();
        cloudLevelsPromise.then(levels => {
            this.CreateCloudSavesPanel(levels);
        }).catch((error) => {

        });
        this.cloudSavesPanel = this.CreateSavesPanel(30, this.basePanelWidth, []);

        this.elements.push(this.cloudSavesPanel);
        uiHandler.elements.push(this.cloudSavesPanel);
    }

    CreateElements(): UIElement[] {
        let ret: UIElement[] = [];

        let backButton = this.CreateBackButton();
        ret.push(backButton);

        this.ResetCloudSavesPanel();
        this.ResetLocalSavesPanel();

        this.cloudSavesOptionsPanel = new Panel(this.baseRightX, this.baseY + 1000, this.basePanelWidth, this.basePanelHeight);
        this.localSavesOptionsPanel = new Panel(this.baseLeftX, this.baseY + 1000, this.basePanelWidth, this.basePanelHeight);

        this.localSavesTitlePanel = new Panel(this.baseRightX, this.baseY - 50, this.basePanelWidth, 40);
        this.cloudSavesTitlePanel = new Panel(this.baseLeftX, this.baseY - 50, this.basePanelWidth, 40);
        let localSavesTitle = new UIText(0,0,"Local Saves", 16, "white");
        this.localSavesTitlePanel.AddChild(localSavesTitle);
        let cloudSavesTitle = new UIText(0,0,"Uploaded Levels", 16, "white");
        this.cloudSavesTitlePanel.AddChild(cloudSavesTitle);
        [localSavesTitle, cloudSavesTitle].forEach(a => {
            a.xOffset = (this.basePanelWidth - 10)/2;
            a.yOffset = -8;
        });

        [this.cloudSavesOptionsPanel, this.localSavesOptionsPanel, this.localSavesTitlePanel, this.cloudSavesTitlePanel].forEach(a => {
            a.backColor = "#1138";
            a.layout = "vertical";
        })


        let cloudBackButton = this.CreateActionButton("Back", () => {
            MyLevelsMenu.selectedCloudId = -1;
        });
        this.cloudSavesOptionsPanel.AddChild(cloudBackButton);

        let localBackButton = this.CreateActionButton("Back", () => {
            MyLevelsMenu.selectedLocalSlot = -1;
        });
        this.localSavesOptionsPanel.AddChild(localBackButton);


        this.buttonLocalDelete = this.CreateActionButton("Delete", () => {
            let confirmed = confirm("Are you sure you want to delete this local save file?");
            if (confirmed) {
                StorageService.SetSavedLevel(MyLevelsMenu.selectedLocalSlot, "", "");
                this.ResetLocalSavesPanel();
            }
        });
        this.buttonLocalDelete.mouseoverBackColor = "#922d";
        this.localSavesOptionsPanel.AddChild(this.buttonLocalDelete);


        this.buttonLocalUpload = this.CreateActionButton("Upload", () => {
            let name = prompt("After uploading this level, you'll still need to beat it from the cloud saves list before other people can play it. What do you want to name this level?");
            if (name) {
                let buttonSlotData = StorageService.GetSavedLevel(MyLevelsMenu.selectedLocalSlot);
                let levelDt = new LevelUploadDT(name, buttonSlotData.level, buttonSlotData.thumb);
                let uploadPromise = DataService.UploadLevel(levelDt);
                uploadPromise.then( (data) => {
                    this.ResetCloudSavesPanel();
                    this.ResetLocalSavesPanel();
                    MyLevelsMenu.selectedCloudId = +data;
                })
            }
        });
        this.localSavesOptionsPanel.AddChild(this.buttonLocalUpload);


        this.buttonLocalEdit = this.CreateActionButton("Edit", () => {
            let buttonSlotData = StorageService.GetSavedLevel(MyLevelsMenu.selectedLocalSlot);
            editorHandler.currentSaveSlot = MyLevelsMenu.selectedLocalSlot;
            editorHandler.EditMap(buttonSlotData.level);
            this.Hide(1);
        });
        this.localSavesOptionsPanel.AddChild(this.buttonLocalEdit);


        ret.push(this.cloudSavesOptionsPanel, this.localSavesOptionsPanel, this.localSavesTitlePanel, this.cloudSavesTitlePanel);
        return ret;
    }

    CreateActionButton(text: string, action: () => void): Button {
        let button = new Button(0, 0, this.basePanelWidth - 10, 70);
        button.borderRadius = 10;

        let buttonText = new UIText(0, 0, text, 20, "white");
        buttonText.xOffset = (this.basePanelWidth - 10) / 2;
        buttonText.yOffset = -20;
        button.AddChild(buttonText);
        button.onClickEvents.push(action);
        return button;
    }

    CreateCloudSavesPanel(levels: LevelDT[]): void {
        let myCloudLevelButtons: MyCloudLevelButton[] = [];

        for (let level of levels) {
            myCloudLevelButtons.push(new MyCloudLevelButton(level));
        }

        let newPanel = this.CreateSavesPanel(this.baseLeftX, this.basePanelWidth, myCloudLevelButtons);
        if (this.cloudSavesPanel) {
            this.cloudSavesPanel.children = newPanel.children;
            this.cloudSavesPanel.scrollableChildren = newPanel.scrollableChildren;
        }
    }

    CreateLocalSavesPanel(): Panel {
        let maxSaveSlot = 15;
        let slotButtons: MyLocalLevelButton[] = [];
        for (let i = 1; i <= maxSaveSlot; i++) {
            let existingSaveLevel = StorageService.GetSavedLevel(i);
            if (existingSaveLevel.level.length) {
                let button = new MyLocalLevelButton(i);
                slotButtons.push(button);
            }
        }
        return this.CreateSavesPanel(this.baseRightX, this.basePanelWidth, slotButtons);
    }

    CreateSavesPanel(x: number, width: number, buttons: (MyLocalLevelButton | MyCloudLevelButton)[]): Panel {
        let myLevelsPanel = new Panel(x, this.baseY, this.basePanelWidth, this.basePanelHeight);
        myLevelsPanel.backColor = "#1138";
        myLevelsPanel.layout = "vertical";

        for (let button of buttons) {
            button.SnapToPlace();
        }

        if (buttons.length == 1) myLevelsPanel.AddChild(new Spacer(0, 0, 88 * 2 + 10, 50 * 2 + 10));
        if (buttons.length == 2) myLevelsPanel.AddChild(new Spacer(0, 0, 88 * 2 + 10, 50 * 2 + 10));

        while (buttons.length > 3) {
            let slotButton = buttons.pop();
            if (slotButton) myLevelsPanel.scrollableChildren.push(slotButton);
        }
        while (buttons.length > 0) {
            let slotButton = buttons.pop();
            if (slotButton) myLevelsPanel.AddChild(slotButton);
        }

        return myLevelsPanel;
    }

    Update(): void {
        if (this.localSavesPanel && this.cloudSavesPanel && this.cloudSavesOptionsPanel && this.localSavesOptionsPanel
            && this.cloudSavesTitlePanel && this.localSavesTitlePanel) {


            if (MyLevelsMenu.selectedCloudId == -1) {
                this.localSavesPanel.targetX = this.baseRightX;
                this.localSavesTitlePanel.targetX = this.baseRightX;
                this.cloudSavesOptionsPanel.targetY = this.baseY + 1000;
            } else {
                this.localSavesPanel.targetX = this.baseRightX + 1000;
                this.localSavesTitlePanel.targetX = this.baseRightX + 1000;
                this.cloudSavesOptionsPanel.targetY = this.baseY;
            }

            if (MyLevelsMenu.selectedLocalSlot == -1) {
                this.cloudSavesPanel.targetX = this.baseLeftX;
                this.cloudSavesTitlePanel.targetX = this.baseLeftX;
                this.localSavesOptionsPanel.targetY = this.baseY + 1000;
            } else {
                this.cloudSavesPanel.targetX = this.baseLeftX - 1000;
                this.cloudSavesTitlePanel.targetX = this.baseLeftX - 1000;
                this.localSavesOptionsPanel.targetY = this.baseY;
            }

        }
    }
}


class MyCloudLevelButton extends Button {
    isSelected: boolean = false;

    constructor(private levelDt: LevelDT) {
        super(0, 0, 88 * 2 + 10, 50 * 2 + 10);

        var thumbnail = new Image;
        thumbnail.src = levelDt.thumbnail;
        thumbnail.width = camera.canvas.width / 24;
        thumbnail.height = camera.canvas.height / 24;
        let imageTile = new ImageTile(thumbnail, 0, 0, thumbnail.width, thumbnail.height);

        // make sure scale of this is good
        let imageFromTile = new ImageFromTile(0, 0, 88 * 2, 50 * 2, imageTile);
        imageFromTile.zoom = 4;
        this.AddChild(imageFromTile);
        let slotText = new UIText(0, 0, levelDt.name, 20, "white");
        slotText.textAlign = "left";
        slotText.xOffset = -230;
        slotText.yOffset = 30;
        this.AddChild(slotText);

        this.onClickEvents.push(() => {
            MyLevelsMenu.selectedCloudId = levelDt.id;
            this.isSelected = true;
        })

        this.Update();
    }

    Update(): void {
        super.Update();
        this.isSelected = (MyLevelsMenu.selectedCloudId == this.levelDt.id);
        this.borderColor = this.isSelected ? "#2F2E" : "#444E";

        this.width = this.targetWidth;
        for (let child of this.children) {
            if (child.targetWidth) child.width = child.targetWidth;
            child.x = child.targetX;
        }
    }
}

class MyLocalLevelButton extends Button {
    isSelected: boolean = false;

    constructor(private slotNumber: number) {
        super(0, 0, 88 * 2 + 10, 50 * 2 + 10);

        let existingSaveLevel = StorageService.GetSavedLevel(slotNumber);
        if (existingSaveLevel.level.length) {
            var thumbnail = new Image;
            thumbnail.src = existingSaveLevel.thumb;
            thumbnail.width = camera.canvas.width / 24;
            thumbnail.height = camera.canvas.height / 24;
            let imageTile = new ImageTile(thumbnail, 0, 0, thumbnail.width, thumbnail.height);

            // make sure scale of this is good
            let imageFromTile = new ImageFromTile(0, 0, 88 * 2, 50 * 2, imageTile);
            imageFromTile.zoom = 4;
            this.AddChild(imageFromTile);
            let slotText = new UIText(0, 0, "Slot " + slotNumber, 20, "white");
            slotText.textAlign = "left";
            slotText.xOffset = -230;
            slotText.yOffset = 30;
            this.AddChild(slotText);
        }

        this.onClickEvents.push(() => {
            MyLevelsMenu.selectedLocalSlot = this.slotNumber;
            this.isSelected = true;
        })

        this.Update();
    }

    Update(): void {
        super.Update();
        this.isSelected = (MyLevelsMenu.selectedLocalSlot == this.slotNumber);
        this.borderColor = this.isSelected ? "#2F2E" : "#444E";

        this.width = this.targetWidth;
        for (let child of this.children) {
            if (child.targetWidth) child.width = child.targetWidth;
            child.x = child.targetX;
        }
    }
}