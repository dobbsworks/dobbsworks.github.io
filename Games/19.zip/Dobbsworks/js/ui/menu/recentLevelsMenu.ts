class RecentLevelsMenu extends Menu {
    stopsMapUpdate = true;
    selectedCloudId: number = -1;
    levels: LevelListing[] = [];
    levelPanel: Panel | null = null;
    levelOptionsPanel: Panel | null = null;

    basePanelWidth = 432;
    baseX = (960 - this.basePanelWidth) / 2;
    baseY = 70;
    basePanelHeight = 400;
    baseLeftX = 30;
    baseRightX = 960 - this.basePanelWidth - 30;

    backgroundColor = "#101";

    CreateElements(): UIElement[] {
        let ret: UIElement[] = [];

        let backButton = this.CreateBackButton();
        ret.push(backButton);

        let getLevelsPromise = DataService.GetRecentLevels();
        getLevelsPromise.then(levels => {
            this.levels = levels;
            this.PopulateLevelPanel();
        }).catch((error) => {

        });

        this.levelPanel = new Panel(this.baseX, this.baseY, this.basePanelWidth, this.basePanelHeight);
        this.levelPanel.backColor = "#1138";
        this.levelPanel.layout = "vertical";
        ret.push(this.levelPanel);

        this.levelOptionsPanel = new Panel(this.baseX + 1000, this.baseY, this.basePanelWidth, this.basePanelHeight);
        this.levelOptionsPanel.backColor = "#1138";
        this.levelOptionsPanel.layout = "vertical";
        ret.push(this.levelOptionsPanel);

        return ret;
    }

    static Reset(): void {
        let menu = <RecentLevelsMenu>MenuHandler.MenuStack.find(a => a instanceof RecentLevelsMenu);
        if (menu) {
            menu.PopulateLevelPanel();
        }
    }

    static GetListing(levelId: number): LevelListing | undefined {
        let menu = <RecentLevelsMenu>MenuHandler.MenuStack.find(a => a instanceof RecentLevelsMenu);
        if (menu) {
            return menu.levels.find(a => a.level.id == levelId);
        }
        return undefined;
    }

    PopulateLevelPanel(): void {
        if (this.levelPanel) {
            let scrollIndex = this.levelPanel.scrollIndex;
            this.levelPanel.children = [];
            this.levelPanel.scrollableChildren = [];

            let buttons = this.levels.map(a => new CloudLevelButton(a, this));
            if (buttons.length == 1) this.levelPanel.AddChild(new Spacer(0, 0, 88 * 2 + 10, 50 * 2 + 10));
            if (buttons.length == 2) this.levelPanel.AddChild(new Spacer(0, 0, 88 * 2 + 10, 50 * 2 + 10));
            while (buttons.length > 3) {
                let button = buttons.pop();
                if (button) this.levelPanel.scrollableChildren.push(button);
            }
            while (buttons.length > 0) {
                let button = buttons.pop();
                if (button) this.levelPanel.AddChild(button);
            }

            for (let i = 0; i < Math.abs(scrollIndex); i++) {
                this.levelPanel.Scroll(scrollIndex > 0 ? -1 : 1);
            }
        }
    }

    ShowLevelDetails(): void {
        let levelListing = this.levels.find(a => a.level.id == this.selectedCloudId);
        if (levelListing && this.levelPanel && this.levelOptionsPanel) {
            this.levelPanel.targetX = this.baseLeftX;
            this.levelOptionsPanel.targetX = this.baseRightX;
            this.levelOptionsPanel.children = [];


            let buttons = new Panel(0, 0, this.levelOptionsPanel.width, 50);
            buttons.margin = 0;
            this.levelOptionsPanel.AddChild(buttons);

            let playButton = new Button(0, 0, 200, 50);
            playButton.onClickEvents.push(() => {
                if (levelListing) {
                    currentMap = LevelMap.FromImportString(levelListing.level.levelData);
                    editorHandler.SwitchToPlayMode();
                    MenuHandler.SubMenu(BlankMenu);
                    DataService.LogLevelPlayStarted(levelListing.level.id);
                    currentLevelId = levelListing.level.id;
                    levelListing.isStarted = true;
                    this.PopulateLevelPanel();
                }
            })
            let playButtonText = new UIText(0, 0, "Play", 20, "white");
            playButton.AddChild(playButtonText);
            playButtonText.xOffset = playButton.width / 2;
            playButtonText.yOffset = -10;
            buttons.AddChild(playButton);


            let editButton = new Button(0, 0, 200, 50);
            editButton.onClickEvents.push(() => {
                if (levelListing) {
                    currentMap = LevelMap.FromImportString(levelListing.level.levelData);
                    editorHandler.isEditorAllowed = true;
                    editorHandler.exportString = "";
                    editorHandler.SwitchToEditMode();
                    MenuHandler.SubMenu(BlankMenu)
                }
            })
            let editButtonText = new UIText(0, 0, "Open in Editor", 20, "white");
            editButton.AddChild(editButtonText);
            editButtonText.xOffset = editButton.width / 2;
            editButtonText.yOffset = -10;
            buttons.AddChild(editButton);

            if (levelListing.wrHolder) {
                let wrText = new UIText(0, 0, "World record: " + Utility.FramesToTimeText(levelListing.level.recordFrames) + " - " + levelListing.wrHolder.username, 20, "white");
                this.levelOptionsPanel.AddChild(wrText);
                wrText.textAlign = "left";
                wrText.xOffset = 10;
                wrText.yOffset = -15;
            }


            let titleText = new UIText(0, 0, levelListing.level.name, 20, "white");
            this.levelOptionsPanel.AddChild(titleText);
            titleText.textAlign = "left";
            titleText.xOffset = 10;
            titleText.yOffset = -15;


            var thumbnail = new Image;
            thumbnail.src = levelListing.level.thumbnail;
            thumbnail.width = camera.canvas.width / 24;
            thumbnail.height = camera.canvas.height / 24;
            let imageTile = new ImageTile(thumbnail, 0, 0, thumbnail.width, thumbnail.height);

            // make sure scale of this is good
            let imageFromTile = new ImageFromTile(0, 0, 422, 50 * 5, imageTile);
            imageFromTile.zoom = 10;
            this.levelOptionsPanel.AddChild(imageFromTile);

        }
    }
}


class CloudLevelButton extends Button {
    isSelected: boolean = false;

    constructor(private levelListing: LevelListing, private containingMenu: RecentLevelsMenu) {
        super(0, 0, 88 * 2 + 10, 50 * 2 + 10);

        if (levelListing.isStarted && !levelListing.isCleared) {
            this.normalBackColor = "#200b";
            this.mouseoverBackColor = "#422b";
        }
        if (levelListing.isCleared) {
            this.normalBackColor = "#020b";
            this.mouseoverBackColor = "#242b";
        }

        let levelDt = levelListing.level;
        var thumbnail = new Image;
        thumbnail.src = levelDt.thumbnail;
        thumbnail.width = camera.canvas.width / 24;
        thumbnail.height = camera.canvas.height / 24;
        let imageTile = new ImageTile(thumbnail, 0, 0, thumbnail.width, thumbnail.height);

        // make sure scale of this is good
        let imageFromTile = new ImageFromTile(0, 0, 88 * 2, 50 * 2, imageTile);
        imageFromTile.zoom = 4;
        this.AddChild(imageFromTile);

        let texts = new Panel(0, 0, 230, 80);
        texts.layout = "vertical";

        for (let text of [
            levelDt.name,
            "by " + levelListing.author.username,
            new Date(Date.parse((levelDt.timestamp + "+00:00"))).toLocaleString()
        ].reverse()) {
            let textLine = new UIText(0, 0, text, 20, "white");
            textLine.textAlign = "left";
            texts.AddChild(textLine);
        }
        texts.AddChild(new Spacer(0, 0, 0, 0));

        this.AddChild(texts);

        this.onClickEvents.push(() => {
            containingMenu.selectedCloudId = this.levelListing.level.id;
            this.isSelected = true;
            containingMenu.ShowLevelDetails();
        })

        this.Update();
    }

    Update(): void {
        super.Update();
        this.isSelected = (this.containingMenu.selectedCloudId == this.levelListing.level.id);
        this.borderColor = this.isSelected ? "#2F2E" : "#444E";

        this.width = this.targetWidth;
        for (let child of this.children) {
            if (child.targetWidth) child.width = child.targetWidth;
            child.x = child.targetX;
        }
    }
}
