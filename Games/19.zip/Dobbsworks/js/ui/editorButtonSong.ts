class EditorButtonSong extends EditorButton {

    constructor(public songId: number) {
        super(tiles["musicnotes"][songId % 6][Math.floor(songId / 6)], songId === 0 ? "Remove level music" : "Set level music");
        this.onClickEvents.push(() => {
            currentMap.songId = songId;
            let songName = audioHandler.levelSongList[this.songId];
            audioHandler.SetBackgroundMusic(songName);
            console.log(this);
        })
    }

    // Update(): void {
    //     super.Update();
    //     let isSelected = editorHandler.currentTool instanceof FillBrush && editorHandler.currentTool.fillType === this.linkedFillType;
    //     this.borderColor = isSelected ? "#FF2E" : "#FF20";
    // }

    // AppendImage(imageTile: ImageTile): EditorButtonTile {
    //     this.AddChild(new ImageFromTile(0, 0, 50, 50, imageTile));
    //     return this;
    // }
}