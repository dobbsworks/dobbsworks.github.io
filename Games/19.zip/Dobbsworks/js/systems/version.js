"use strict";
var version = '0.7.0';
