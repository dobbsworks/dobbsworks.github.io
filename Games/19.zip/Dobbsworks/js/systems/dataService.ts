class DataService {


    static DefaultErrorHandler(error: string): void {
        // no additional actions, just send to console
    }


    static BaseCall(urlAction: string,
        method: string,
        body: any,
        onSuccess: (data: any) => void,
        onError: (data: any) => void = DataService.DefaultErrorHandler): void {

        let baseUrl = "https://dabbleworlds1.azurewebsites.net/api/";
        if (window.location.href.indexOf("localhost") > -1 ) {
        //if (window.location.href.indexOf("localhost") > -1 || window.location.href.indexOf("127.0.0.1")) {
            baseUrl = "https://localhost:7121/api/";
        }
        let endpoint = baseUrl + urlAction;
        let init = <RequestInit>{ method: method };
        if (method == "POST") {
            init.body = JSON.stringify(body);
            //init.mode = 'no-cors',
            init.headers = {
                'Accept': 'application/json, text/plain, */*',
                'Content-Type': 'application/json'
            };
        }
        fetch(endpoint, init).then(response => {
            if (response.status && !response.ok) {
                throw new Error("Status " + response.status);
            }
            let raw = response.text();
            return raw;
        }).then(response => {
            if (response.startsWith("[") || response.startsWith("{")) {
                response = JSON.parse(response);
            }
            onSuccess(response);
        }).catch(error => {
            console.error(error);
            (<any>document.getElementById("errorLog")).innerText += error + " \n" + endpoint + " \n" + error.stack;
            onError(error);
        });
    }

    static BaseGet(urlAction: string, onSuccess: (data: any) => void, onError: (data: any) => void = DataService.DefaultErrorHandler): void {
        DataService.BaseCall(urlAction, "GET", null, onSuccess, onError);
    }

    static BasePost(urlAction: string, body: any, onSuccess: (data: any) => void, onError: (data: any) => void = DataService.DefaultErrorHandler): void {
        DataService.BaseCall(urlAction, "POST", body, onSuccess, onError);
    }




    static SampleSimpleCall(): void {
        DataService.BaseGet("SampleApi/SampleSimpleCall", (data) => {
            console.log(data);
        });
    }

    static SampleSimpleCall2(): void {
        DataService.BaseGet("SampleApi/SampleSimpleCall2/myText", (data) => {
            console.log(data);
        });
    }

    static SamplePOST(): void {
        DataService.BasePost("SampleApi/SamplePost", { Id: 1, DiscordId: "test", Username: "test test" }, (data) => {
            console.log(data);
        });
    }

    static GetMyLevels(): Promise<LevelDT[]> {
        return new Promise<LevelDT[]>((resolve, reject) => {
            DataService.BaseGet("Levels/MyLevels", resolve, reject);
        })
    }

    static GetRecentLevels(): Promise<LevelListing[]> {
        return new Promise<LevelListing[]>((resolve, reject) => {
            DataService.BaseGet("Levels/RecentLevels", resolve, reject);
        })
    }

    static UploadLevel(levelUpload: LevelUploadDT): Promise<string> {
        return new Promise<string>((resolve, reject) => {
            DataService.BasePost("Levels/UploadLevel", levelUpload, resolve, reject);
        })
    }

    static LogLevelPlayStarted(levelId: number): Promise<number> {
        return new Promise<number>((resolve, reject) => {
            DataService.BasePost("Levels/LogLevelPlayStarted", {levelId: levelId}, resolve, reject);
        })
    }

    static LogLevelPlayDone(progress: LevelProgressModel): Promise<LevelAwardsModel> {
        return new Promise<LevelAwardsModel>((resolve, reject) => {
            DataService.BasePost("Levels/LogLevelPlayDone", progress, resolve, reject);
        })
    }
}