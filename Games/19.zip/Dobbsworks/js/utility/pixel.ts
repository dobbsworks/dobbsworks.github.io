interface Pixel {
    xPixel: number,
    yPixel: number
}