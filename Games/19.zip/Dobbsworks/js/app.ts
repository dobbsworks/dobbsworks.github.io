
window.onload = Initialize;
let tiles: any = {};
let camera: Camera;
let currentMap: LevelMap;
let mouseHandler: MouseHandler;
let editorHandler = new EditorHandler();
let uiHandler = new UiHandler();
let audioHandler: AudioHandler;
let currentLevelId = -1;

function Initialize() {
    LoadImageSources();
    let canvas = <HTMLCanvasElement>document.getElementById("canvas");
    camera = new Camera(canvas);

    mouseHandler = new MouseHandler(canvas);
    audioHandler = new AudioHandler();
    audioHandler.Initialize();
    KeyboardHandler.InitKeyHandlers();
    CreateTestMap();
    setInterval(MainLoop, 1000 / 60);
}

function LoadImageSources() {
    let container = document.getElementById("imageResources");
    let images = container?.querySelectorAll("img");
    if (images) for (let img of Array.from(images)) {
        let src = img.src.split(".png")[0];
        let imgName = src.split("/")[src.split("/").length - 1];
        if (src.indexOf("/bg/") > -1) imgName = "bg_" + imgName;
        let tileMap: any = {};
        let rows = +(img.dataset.rows ?? 1) || 1;
        let cols = +(img.dataset.cols ?? 1) || 1;
        let rowHeight = img.height / rows;
        let colWidth = img.width / cols;
        for (let col = 0; col < cols; col++) {
            let tileCol: any = {};
            for (let row = 0; row < rows; row++) {
                let imageTile = new ImageTile(
                    img, col * colWidth, row * rowHeight, colWidth, rowHeight);
                tileCol[row] = imageTile;
            }
            tileMap[col] = tileCol;
        }
        tiles[imgName] = tileMap;
    }
}

function MainLoop() {
    Update();
    Draw();
    audioHandler.Update();
    let perf = <HTMLElement>document.getElementById("perf");
    perf.innerHTML = BenchmarkService.GetReports();
    let otherData = <HTMLElement>document.getElementById("data");
    otherData.innerHTML = "Version: " + version;
    BenchmarkService.Log("IDLE")
}

function Draw() {
    if (currentMap) currentMap.Draw(camera);
    MenuHandler.Draw(camera);
    BenchmarkService.Log("DrawEditor");
    if (editorHandler.isInEditMode) editorHandler.Draw(camera);
    BenchmarkService.Log("DrawUI");
    uiHandler.Draw(camera.ctx);
    BenchmarkService.Log("DrawDone");
}


var debugMode = false;
//var replayHandler: ReplayHandler | null; = new ReplayHandler();
//replayHandler.ImportFromBase64("ABcgGCQCNAg1BDEQIRUxBSEXIAwiBSAEIQYmAiIHJgIkAgQIJAIlAyEBMQERCDEBIQMgAyIJIAYkCAQDJAUgDSEcJAIiNAIFAAMQBwANEAgABRAEABUQDwAFEQkBHAADAgQyFyILMgM0AzEBEQoUARIDAg4ABQECEQMxCzIeOQExBiEFARgADQgGAAYIBAAFCAUAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA=");
function Update() {
    //replayHandler.LoadFrame();
    KeyboardHandler.Update();
    MenuHandler.Update();

    let doesMenuBlockMapUpdate = MenuHandler.CurrentMenu?.stopsMapUpdate;

    if (KeyboardHandler.IsKeyPressed(KeyAction.Fullscreen, true)) document.getElementById("canvas")?.requestFullscreen();
    if (KeyboardHandler.IsKeyPressed(KeyAction.Debug1, true)) debugMode = !debugMode;
    //if (KeyboardHandler.IsKeyPressed(KeyAction.Reset, true)) window.location.reload();
    if (KeyboardHandler.IsKeyPressed(KeyAction.EditToggle, true)) {
        if (editorHandler.isInEditMode) editorHandler.SwitchToPlayMode();
        else if (editorHandler.isEditorAllowed) editorHandler.SwitchToEditMode();
    }
    if (debugMode) {
        if (KeyboardHandler.IsKeyPressed(KeyAction.Debug2, true)) {
            if (currentMap && !editorHandler.isInEditMode && !doesMenuBlockMapUpdate) currentMap.Update();
        }
        if (KeyboardHandler.IsKeyPressed(KeyAction.Debug3, true)) {
            let player = <Player>currentMap.mainLayer.sprites[0];
            player.LoadHistory();
        }
    } else {
        //replayHandler.StoreFrame();

        if (currentMap && !doesMenuBlockMapUpdate) {
            if (editorHandler.isInEditMode) {
                currentMap.frameNum++;
                currentMap.mainLayer.Update();
            } else {
                currentMap.Update();
            }
        }

        if (currentMap && !doesMenuBlockMapUpdate && !editorHandler.isInEditMode && currentMap.CanPause() && !MenuHandler.CurrentMenu?.blocksPause) {
            let isOnMainMenu = MenuHandler.CurrentMenu instanceof MainMenu;
            if (KeyboardHandler.IsKeyPressed(KeyAction.Pause, true) && !isOnMainMenu) {
                let msSinceUnpause = (+(new Date()) - +PauseMenu.UnpauseTime);
                if (msSinceUnpause > 100) MenuHandler.SubMenu(PauseMenu);
            }
        }

    }
    uiHandler.Update();
    editorHandler.Update();
    camera.Update();
    mouseHandler.UpdateMouseChanged();
}


function CreateTestMap() {

    let mainLayer = new LevelLayer(TargetLayer.main);
    let wireLayer = new LevelLayer(TargetLayer.wire);
    let waterLayer = new LevelLayer(TargetLayer.water);
    let semisolidLayer = new LevelLayer(TargetLayer.semisolid);
    let backdropLayer = new LevelLayer(TargetLayer.backdrop);
    TileType.RegisterTiles();

    let map = new LevelMap(mainLayer, wireLayer, waterLayer, semisolidLayer, backdropLayer);
    currentMap = map;
    editorHandler.Update(); // need to run one update cycle to init + set "default" positions
    editorHandler.sprites.push(new EditorSprite(Player, { tileX: 4, tileY: 16 }));

    currentMap = LevelMap.FromImportString(`0.6.0;12;0;0;6|#b25900,#0c0c26,0.00,1.00,0.50;AY,#7f26d8,0,0,1,0,0,0;AI,#501084,0,0,0.8,-3,1,0;AI,#4c18e5,0,0,0.8,-5,0,0;AL,#5eeded,0,0,1,0,0,0|AA/AA/AA/AA/AA/AA/AA/AA/AA/AA/AA/AAP|AA/AA/AA/AA/AA/AA/AA/AA/AA/AA/AA/AAP|AARDKAAACDOAAAfDQAAAbCeXAA/AA/AA/AACBSHAATCeEAAGCeEAAGCeEAAGCeEAAGCeEAAGCeEAAGCeEAAjCeCAABCeEAABCeCAABCeEAABCeCAABCeAAAFCeCAABCeAAAFCeCAABCeAAACChCCeCAABCeAAAFCeCAABCeAAAFCeJAABCeJAAQBSIAA/AA/AAP|AA/AA/AA/AA/AA/AA/AA/AA/AAqAFAAAKAFAAAKAFAAAKAFAAA/AA/|AjEAAGAjAAACAjAAAAADAAAEAjAAACAjAADBAAEAZAAACAFAAAGAjAAACAjAAAGAjAAACAjAAAGAjEAA/AA/AA/AA/AA/AA/AA/AA/AA/AA/AAC|ABA3AD;AbAJAG;AbATAG;AAAUAF;AoApAH`);
    //EditorSaveSlotButton.Buttons[1].SaveToSlot();

    editorHandler.SwitchToPlayMode();
    [...editorHandler.editorParentElementsTop, ...editorHandler.editorParentElementsBottom].forEach(a => a.SnapToPlace());

    MenuHandler.CreateMenu(InitialMenu);
}

var player: Player;