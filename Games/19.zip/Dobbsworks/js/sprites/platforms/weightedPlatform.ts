class WeightedPlatform extends BasePlatform {

    public tilesetRow: number = 1;
    public weightThreshold: number = 1;
    public originalY: number = -9999;
    public speed: number = 0.2;

    Update(): void {
        this.MoveByVelocity();
        if (this.originalY == -9999) this.originalY = this.y;
        let numberOfFullRiders = this.GetFullRiderCount();
        let hasPartialRider = this.GetOneFootRiderCount() > 0;

        if (numberOfFullRiders >= this.weightThreshold) {
            this.tilesetRow = 4;
            this.dy = this.speed;
        } else {
            if (this.y == this.originalY) {
                this.tilesetRow = 1;
                this.dy = 0;
                if (numberOfFullRiders > 0 || hasPartialRider) {
                    this.tilesetRow = 3;
                }
            } else {
                this.tilesetRow = 2;
                this.dy = -this.speed;
                if (hasPartialRider) {
                    this.tilesetRow = 3;
                    this.dy = 0;
                }
            }
        }
        
        if (this.y < this.originalY) {
            this.y = this.originalY;
        }
    }
}