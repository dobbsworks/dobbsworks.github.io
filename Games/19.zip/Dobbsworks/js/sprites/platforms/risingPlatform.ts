class RisingPlatform extends BasePlatform {

    public tilesetRow: number = 6;
    public isStarted = false;

    Update(): void {
        if (this.isStarted) {
            this.dy -= 0.04;
            if (this.dy < -1) this.dy = -1;
        }
        if (!this.isStarted && this.IsPlayerStandingOn()) {
            this.isStarted = true;
            this.dy = 1.2;
        }
        this.MoveByVelocity();
        if (this.y < (this.layer.tiles[0][0].tileY * this.layer.tileHeight) - 12) {
            this.isActive = false;
        }
    }
}