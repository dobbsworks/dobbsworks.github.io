class PricklySnouter extends Snouter {

    canBeBouncedOn = false;
    ammo: SpriteType = PricklySnouterBullet;
    frameCol = 1;
}