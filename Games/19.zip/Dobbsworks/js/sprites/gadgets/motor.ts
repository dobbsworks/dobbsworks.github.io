class Motor extends Sprite {
    public height: number = 12;
    public width: number  = 12;
    public respectsSolidTiles: boolean = false;
    
    private isInitialized = false;
    private connectedSprite: Sprite | null = null;
    private connectionDistance: number = 0;
    private isOnTrack = false;
    //private trackTile: LevelTile | null = null;

    Initialize(): void {
        // find closest non-player sprite below motor
        let spritesBelow = this.layer.sprites.filter(a => a.x < this.xRight && a.xRight > this.x && a.y > this.yBottom);
        if (spritesBelow.length == 0) {
            return;
        }
        spritesBelow.sort((a,b) => a.y - b.y);
        this.connectedSprite = spritesBelow[0];
        this.connectionDistance = this.connectedSprite.y - this.y;
    }

    Update(): void {
        if (!this.isInitialized) {
            this.isInitialized = true;
            this.Initialize();
        }

        let tileSize = 12;
        let currentTile = this.layer.GetTileByPixel(this.xMid, this.yMid).GetWireNeighbor();
        if (this.isOnTrack && currentTile?.tileType.isTrack) {
            let targetSpeed = currentTile.tileType.trackDirectionEquation(this.x, this.y);
            let targetPoint = currentTile.tileType.trackEquation(this.x + targetSpeed.dx, this.y + targetSpeed.dy);
            this.dx = targetPoint.x - this.x;
            this.dy = targetPoint.y - this.y;
        } else {
            this.ApplyGravity();
            let oldX = this.x;
            let oldY = this.y;
            this.MoveByVelocity();

            if (currentTile?.tileType.isTrack) {
                let previousTile = this.layer.GetTileByPixel(oldX + this.width/2, oldY + this.height/2).GetWireNeighbor();
                if (currentTile == previousTile) {
                    // check if we "crossed" the track
                    let crossedTrack = currentTile.tileType.trackCrossedEquation(oldX, oldY, this.x, this.y);
                    if (crossedTrack) this.isOnTrack = true;
                }
            }
        }


        // if (!this.trackTile) {
        //     let currentTile = this.layer.GetTileByPixel(this.xMid, this.yMid).GetWireNeighbor();
        //     if (currentTile?.tileType.isTrack) {
        //         this.trackTile = currentTile;
        //     }
        // }

        // if (this.trackTile) {
        //     let targetX = this.x;
        //     let targetY = this.y;
        //     if (this.trackTile.tileType == TileType.TrackHorizontal) {
        //         targetY = this.trackTile.GetTopPixel();
        //         this.dx = 0.5;
        //         this.dy = 0;
        //     }
        // }

        // this.MoveByVelocity();
        this.MoveConnectedSprite();
    }

    MoveConnectedSprite(): void {
        if (!this.connectedSprite) return;
        if (!this.connectedSprite.updatedThisFrame) this.connectedSprite.Update();

        let player = <Player>this.layer.sprites.find(a => a instanceof Player);
        if (player) {
            if (player.heldItem == this.connectedSprite) {
                this.connectedSprite = null;
                return;
            }
        }
        

        this.connectedSprite.x = this.xMid - this.connectedSprite.width / 2;
        this.connectedSprite.y = this.y + this.connectionDistance;
        this.connectedSprite.dx = this.dx;
        this.connectedSprite.dy = this.dy;
    }

    GetFrameData(frameNum: number): FrameData {
        let col = Math.floor(frameNum / 10) % 2;
        return {
            imageTile: tiles["motorTrack"][col][0],
            xFlip: false,
            yFlip: false,
            xOffset: 0,
            yOffset: 0
        };
    }

    OnAfterDraw(camera: Camera): void {
        let x = (this.xMid - camera.x) * camera.scale + camera.canvas.width / 2;
        let y = (this.yBottom - camera.y) * camera.scale + camera.canvas.height / 2;
        camera.ctx.fillStyle = "#222";
        camera.ctx.fillRect(x - 1 * camera.scale, y - 1 * camera.scale, 2 * camera.scale, (this.connectionDistance - 11) * camera.scale)
    }
    
}