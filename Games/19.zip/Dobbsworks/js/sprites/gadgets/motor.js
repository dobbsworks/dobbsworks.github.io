"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var Motor = /** @class */ (function (_super) {
    __extends(Motor, _super);
    function Motor() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.height = 12;
        _this.width = 12;
        _this.respectsSolidTiles = false;
        _this.isInitialized = false;
        _this.connectedSprite = null;
        _this.connectionDistance = 0;
        _this.isOnTrack = false;
        return _this;
    }
    //private trackTile: LevelTile | null = null;
    Motor.prototype.Initialize = function () {
        var _this = this;
        // find closest non-player sprite below motor
        var spritesBelow = this.layer.sprites.filter(function (a) { return a.x < _this.xRight && a.xRight > _this.x && a.y > _this.yBottom; });
        if (spritesBelow.length == 0) {
            return;
        }
        spritesBelow.sort(function (a, b) { return a.y - b.y; });
        this.connectedSprite = spritesBelow[0];
        this.connectionDistance = this.connectedSprite.y - this.y;
    };
    Motor.prototype.Update = function () {
        if (!this.isInitialized) {
            this.isInitialized = true;
            this.Initialize();
        }
        var currentTile = this.layer.GetTileByPixel(this.xMid, this.yMid).GetWireNeighbor();
        if (this.isOnTrack && (currentTile === null || currentTile === void 0 ? void 0 : currentTile.tileType.isTrack)) {
            var targetSpeed = currentTile.tileType.trackDirectionEquation(this.x, this.y);
            var targetPoint = currentTile.tileType.trackEquation(this.x + targetSpeed.dx, this.y + targetSpeed.dy);
            this.dx = targetPoint.x - this.x;
            this.dy = targetPoint.y - this.y;
        }
        else {
            this.ApplyGravity();
            var oldX = this.x;
            var oldY = this.y;
            this.MoveByVelocity();
            if (currentTile === null || currentTile === void 0 ? void 0 : currentTile.tileType.isTrack) {
                var previousTile = this.layer.GetTileByPixel(oldX + this.width / 2, oldY + this.height / 2).GetWireNeighbor();
                if (currentTile == previousTile) {
                    // check if we "crossed" the track
                    var crossedTrack = currentTile.tileType.trackCrossedEquation(oldX, oldY, this.x, this.y);
                    if (crossedTrack)
                        this.isOnTrack = true;
                }
            }
        }
        // if (!this.trackTile) {
        //     let currentTile = this.layer.GetTileByPixel(this.xMid, this.yMid).GetWireNeighbor();
        //     if (currentTile?.tileType.isTrack) {
        //         this.trackTile = currentTile;
        //     }
        // }
        // if (this.trackTile) {
        //     let targetX = this.x;
        //     let targetY = this.y;
        //     if (this.trackTile.tileType == TileType.TrackHorizontal) {
        //         targetY = this.trackTile.GetTopPixel();
        //         this.dx = 0.5;
        //         this.dy = 0;
        //     }
        // }
        // this.MoveByVelocity();
        this.MoveConnectedSprite();
    };
    Motor.prototype.MoveConnectedSprite = function () {
        if (!this.connectedSprite)
            return;
        if (!this.connectedSprite.updatedThisFrame)
            this.connectedSprite.Update();
        var player = this.layer.sprites.find(function (a) { return a instanceof Player; });
        if (player) {
            if (player.heldItem == this.connectedSprite) {
                this.connectedSprite = null;
                return;
            }
        }
        this.connectedSprite.x = this.xMid - this.connectedSprite.width / 2;
        this.connectedSprite.y = this.y + this.connectionDistance;
        this.connectedSprite.dx = this.dx;
        this.connectedSprite.dy = this.dy;
    };
    Motor.prototype.GetFrameData = function (frameNum) {
        var col = Math.floor(frameNum / 10) % 2;
        return {
            imageTile: tiles["motorTrack"][col][0],
            xFlip: false,
            yFlip: false,
            xOffset: 0,
            yOffset: 0
        };
    };
    Motor.prototype.OnAfterDraw = function (camera) {
        var x = (this.xMid - camera.x) * camera.scale + camera.canvas.width / 2;
        var y = (this.yBottom - camera.y) * camera.scale + camera.canvas.height / 2;
        camera.ctx.fillStyle = "#222";
        camera.ctx.fillRect(x - 1 * camera.scale, y - 1 * camera.scale, 2 * camera.scale, (this.connectionDistance - 11) * camera.scale);
    };
    return Motor;
}(Sprite));
