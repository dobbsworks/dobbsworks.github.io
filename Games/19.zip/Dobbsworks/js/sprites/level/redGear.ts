class CopperGear extends GoldGear {
    isRequired = false;
    frameRow = 2;   
}