class MapSizeEditor extends Panel {
    constructor() {
        super(85, 85, camera.canvas.width - 85 * 2, camera.canvas.height - 85 * 2);
        this.layout = "vertical";
        let topPanel = new Panel(0, 0, this.width, 70);
        let midPanel = new Panel(0, 0, this.width, 210);
        let bottomPanel = new Panel(0, 0, this.width, 70);
        [bottomPanel, midPanel, topPanel].forEach(x => {
            this.AddChild(x);
        });
        let leftPanel = new Panel(0, 0, 70, midPanel.height);
        let rightPanel = new Panel(0, 0, 70, midPanel.height);
        midPanel.AddChild(leftPanel);
        midPanel.AddChild(rightPanel);

        [topPanel, bottomPanel].forEach(panel => {
            let ySide: -1 | 1 = panel == topPanel ? -1 : 1;
            let tileRowIndex = panel == topPanel ? 7 : 8;
            panel.AddChild(new Spacer(0, 0, (midPanel.width - 210) / 2, 60));
            if (ySide == 1) panel.AddChild(new EditorMapSizeButton(tiles["editor"][5][1], 0, ySide, -1, this));
            panel.AddChild(new SpacedImagePanel(tiles["editor"][4][tileRowIndex]));
            if (ySide == 1) panel.AddChild(new EditorMapSizeButton(tiles["editor"][5][0], 0, ySide, 1, this));
            panel.AddChild(new Spacer(0, 0, (midPanel.width - 210) / 2, 60));
        });

        [leftPanel, rightPanel].forEach(panel => {
            panel.layout = "vertical";
            let xSide: -1 | 1 = panel == leftPanel ? -1 : 1;
            let tileRowIndex = panel == leftPanel ? 6 : 5;
            if (xSide == 1) panel.AddChild(new EditorMapSizeButton(tiles["editor"][5][1], xSide, 0, -1, this));
            panel.AddChild(new SpacedImagePanel(tiles["editor"][4][tileRowIndex]));
            if (xSide == 1) panel.AddChild(new EditorMapSizeButton(tiles["editor"][5][0], xSide, 0, 1, this));
        });
    }

    margin = 0;
    backColor = "#1138";


    ChangeMapSize(dLeft: number, dRight: number, dTop: number, dBottom: number) {
        let layers = currentMap.GetLayerList();
        if (currentMap.mapHeight + dBottom < 12) {
            dBottom = 12 - currentMap.mapHeight;
        }

        let mapWidth = layers[0].tiles.length;
        if (mapWidth + dRight < 20) {
            dRight = 20 - mapWidth;
        }

        console.log(dLeft, dRight, dTop, dBottom)

        if (dRight < 0) {
            layers.forEach(a => a.tiles.splice(a.tiles.length + dRight, -dRight));
        }
        if (dRight > 0) {
            layers.forEach(a => {
                let newColIndex = a.tiles.length;
                let colHeight = a.tiles[0].length;
                for (let y = 0; y < colHeight; y++) {
                    a.SetTile(newColIndex, y, TileType.Air);
                }
            });
        }
        if (dBottom < 0) {
            currentMap.mapHeight += dBottom;
            layers.forEach(a => a.tiles.forEach(col => col.splice(col.length + dBottom, -dBottom)));
        }
        if (dBottom > 0) {
            currentMap.mapHeight += dBottom;
            layers.forEach(a => {
                let newRowIndex = a.tiles[0].length;
                let rowWidth = a.tiles.length;
                for (let x = 0; x < rowWidth; x++) {
                    a.SetTile(x, newRowIndex, TileType.Air);
                }
            });
        }
        // if (dLeft > 0) {
        //     layers.forEach(a => {
        //         let newColIndex = a.tiles.length;
        //         let colHeight = a.tiles[0].length;
        //         for (let y = 0; y < colHeight; y++) {
        //             a.SetTile(newColIndex, y, TileType.Air);
        //         }
        //     });
        // }

        layers.forEach(a => a.isDirty = true);
    }




    Draw(ctx: CanvasRenderingContext2D) {
        super.Draw(ctx);
        if (!this.isHidden) {

            // draw all layers (no sky) on the panel
            // use cached canvases
            // find scale that fits entire map
            // eventually center it

            let maxWidth = this.width - 80 * 2;
            let maxHeight = this.height - 80 * 2;
            if (maxHeight <= 0 || maxWidth <= 0) return;

            // based on max size, find proportional max panel that can fit within max size
            let subpanelWidth = maxWidth;
            let subpanelHeight = maxHeight;

            let subPanelX = this.x + this.width / 2 - subpanelWidth / 2;
            let subPanelY = this.x + this.height / 2 - subpanelHeight / 2;

            ctx.fillStyle = "#aaa";
            ctx.fillRect(subPanelX, subPanelY, subpanelWidth, subpanelHeight);

            for (let layer of currentMap.GetLayerList()) {
                ctx.drawImage(layer.cachedCanvas, subPanelX, subPanelY, subpanelWidth, subpanelHeight);
            }
        }
    }
}


class SpacedImagePanel extends Panel {
    constructor(imageTile: ImageTile) {
        super(0, 0, 60, 60);
        this.AddChild(new ImageFromTile(0, 0, 50, 50, imageTile));
    }
}


class EditorMapSizeButton extends EditorButton {
    constructor(imageTile: ImageTile, xSide: -1 | 0 | 1, ySide: -1 | 0 | 1, increaseOrDecrease: -1 | 1, editor: MapSizeEditor) {
        super(imageTile, "Edit map size");
        this.onClickEvents.push(
            () => {
                let dLeft = xSide == -1 ? increaseOrDecrease : 0;
                let dRight = xSide == 1 ? increaseOrDecrease : 0;
                let dTop = ySide == -1 ? increaseOrDecrease : 0;
                let dBottom = ySide == 1 ? increaseOrDecrease : 0;
                editor.ChangeMapSize(dLeft, dRight, dTop, dBottom);
            }
        );
    }
}