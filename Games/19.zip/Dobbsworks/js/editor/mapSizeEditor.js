"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var MapSizeEditor = /** @class */ (function (_super) {
    __extends(MapSizeEditor, _super);
    function MapSizeEditor() {
        var _this = _super.call(this, 85, 85, camera.canvas.width - 85 * 2, camera.canvas.height - 85 * 2) || this;
        _this.margin = 0;
        _this.backColor = "#1138";
        _this.layout = "vertical";
        var topPanel = new Panel(0, 0, _this.width, 70);
        var midPanel = new Panel(0, 0, _this.width, 210);
        var bottomPanel = new Panel(0, 0, _this.width, 70);
        [bottomPanel, midPanel, topPanel].forEach(function (x) {
            _this.AddChild(x);
        });
        var leftPanel = new Panel(0, 0, 70, midPanel.height);
        var rightPanel = new Panel(0, 0, 70, midPanel.height);
        midPanel.AddChild(leftPanel);
        midPanel.AddChild(rightPanel);
        [topPanel, bottomPanel].forEach(function (panel) {
            var ySide = panel == topPanel ? -1 : 1;
            var tileRowIndex = panel == topPanel ? 7 : 8;
            panel.AddChild(new Spacer(0, 0, (midPanel.width - 210) / 2, 60));
            if (ySide == 1)
                panel.AddChild(new EditorMapSizeButton(tiles["editor"][5][1], 0, ySide, -1, _this));
            panel.AddChild(new SpacedImagePanel(tiles["editor"][4][tileRowIndex]));
            if (ySide == 1)
                panel.AddChild(new EditorMapSizeButton(tiles["editor"][5][0], 0, ySide, 1, _this));
            panel.AddChild(new Spacer(0, 0, (midPanel.width - 210) / 2, 60));
        });
        [leftPanel, rightPanel].forEach(function (panel) {
            panel.layout = "vertical";
            var xSide = panel == leftPanel ? -1 : 1;
            var tileRowIndex = panel == leftPanel ? 6 : 5;
            if (xSide == 1)
                panel.AddChild(new EditorMapSizeButton(tiles["editor"][5][1], xSide, 0, -1, _this));
            panel.AddChild(new SpacedImagePanel(tiles["editor"][4][tileRowIndex]));
            if (xSide == 1)
                panel.AddChild(new EditorMapSizeButton(tiles["editor"][5][0], xSide, 0, 1, _this));
        });
        return _this;
    }
    MapSizeEditor.prototype.ChangeMapSize = function (dLeft, dRight, dTop, dBottom) {
        var layers = currentMap.GetLayerList();
        if (currentMap.mapHeight + dBottom < 12) {
            dBottom = 12 - currentMap.mapHeight;
        }
        var mapWidth = layers[0].tiles.length;
        if (mapWidth + dRight < 20) {
            dRight = 20 - mapWidth;
        }
        console.log(dLeft, dRight, dTop, dBottom);
        if (dRight < 0) {
            layers.forEach(function (a) { return a.tiles.splice(a.tiles.length + dRight, -dRight); });
        }
        if (dRight > 0) {
            layers.forEach(function (a) {
                var newColIndex = a.tiles.length;
                var colHeight = a.tiles[0].length;
                for (var y = 0; y < colHeight; y++) {
                    a.SetTile(newColIndex, y, TileType.Air);
                }
            });
        }
        if (dBottom < 0) {
            currentMap.mapHeight += dBottom;
            layers.forEach(function (a) { return a.tiles.forEach(function (col) { return col.splice(col.length + dBottom, -dBottom); }); });
        }
        if (dBottom > 0) {
            currentMap.mapHeight += dBottom;
            layers.forEach(function (a) {
                var newRowIndex = a.tiles[0].length;
                var rowWidth = a.tiles.length;
                for (var x = 0; x < rowWidth; x++) {
                    a.SetTile(x, newRowIndex, TileType.Air);
                }
            });
        }
        // if (dLeft > 0) {
        //     layers.forEach(a => {
        //         let newColIndex = a.tiles.length;
        //         let colHeight = a.tiles[0].length;
        //         for (let y = 0; y < colHeight; y++) {
        //             a.SetTile(newColIndex, y, TileType.Air);
        //         }
        //     });
        // }
        layers.forEach(function (a) { return a.isDirty = true; });
    };
    MapSizeEditor.prototype.Draw = function (ctx) {
        _super.prototype.Draw.call(this, ctx);
        if (!this.isHidden) {
            // draw all layers (no sky) on the panel
            // use cached canvases
            // find scale that fits entire map
            // eventually center it
            var maxWidth = this.width - 80 * 2;
            var maxHeight = this.height - 80 * 2;
            if (maxHeight <= 0 || maxWidth <= 0)
                return;
            // based on max size, find proportional max panel that can fit within max size
            var subpanelWidth = maxWidth;
            var subpanelHeight = maxHeight;
            var subPanelX = this.x + this.width / 2 - subpanelWidth / 2;
            var subPanelY = this.x + this.height / 2 - subpanelHeight / 2;
            ctx.fillStyle = "#aaa";
            ctx.fillRect(subPanelX, subPanelY, subpanelWidth, subpanelHeight);
            for (var _i = 0, _a = currentMap.GetLayerList(); _i < _a.length; _i++) {
                var layer = _a[_i];
                ctx.drawImage(layer.cachedCanvas, subPanelX, subPanelY, subpanelWidth, subpanelHeight);
            }
        }
    };
    return MapSizeEditor;
}(Panel));
var SpacedImagePanel = /** @class */ (function (_super) {
    __extends(SpacedImagePanel, _super);
    function SpacedImagePanel(imageTile) {
        var _this = _super.call(this, 0, 0, 60, 60) || this;
        _this.AddChild(new ImageFromTile(0, 0, 50, 50, imageTile));
        return _this;
    }
    return SpacedImagePanel;
}(Panel));
var EditorMapSizeButton = /** @class */ (function (_super) {
    __extends(EditorMapSizeButton, _super);
    function EditorMapSizeButton(imageTile, xSide, ySide, increaseOrDecrease, editor) {
        var _this = _super.call(this, imageTile, "Edit map size") || this;
        _this.onClickEvents.push(function () {
            var dLeft = xSide == -1 ? increaseOrDecrease : 0;
            var dRight = xSide == 1 ? increaseOrDecrease : 0;
            var dTop = ySide == -1 ? increaseOrDecrease : 0;
            var dBottom = ySide == 1 ? increaseOrDecrease : 0;
            editor.ChangeMapSize(dLeft, dRight, dTop, dBottom);
        });
        return _this;
    }
    return EditorMapSizeButton;
}(EditorButton));
