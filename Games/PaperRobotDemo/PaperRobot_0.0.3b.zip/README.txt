Paper Robot
v0.0.3b


Demo Installation
Drag the contents of the included zip file into a folder of 
your choice. Then double-click PaperRobot_0.0.3b.exe to
start the game.

Crash logs are placed in "%appdata%\Godot\app_userdata\Paper Robot\logs"

Controls for Keyboard / Controller

WASD / left joystick - move, navigate menus
Space / A - jump
Q / B - gear spin, menu cancel
Esc / Start - pause
E / X - partner ability
F10 - toggle metrics


