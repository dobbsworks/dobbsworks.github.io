﻿
var itemTypes = [];

function ItemType() {

}

function Item(type) {
    this.type = type;
}