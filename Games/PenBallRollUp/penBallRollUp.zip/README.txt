Pen Ball: ROLL UP!
A very original game straight from the Dabble Works
https://dabbleworks.github.io/


CONTROLS
==================
Roll with WASD
Move the camera with the mouse
Exit the game with ESC
Retry with 6


INSTRUCTIONS
==================
Roll Nina the Cat into things that are smaller than her
to absorb their souls so you can roll into bigger things 
until you conquer the world (or time runs out).


ALSO
==================
If you want a copy of my Steam game Pen Pals (a merge-em-up
that's frankly much higher quality than this game), hit 
me up on Discord with a screenshot of your best ROLL UP 
score, I probably have some keys leftover for the most 
skilled of rollers. 